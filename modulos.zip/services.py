# formularios/services.py
from django.db import transaction

from .models import Formulario, EntregaFormulario
from academico.models import Curso, Matricula
from core.models import Estudiante


class ServicioFormulario:
    """Lógica de negocio de formularios, reutilizable por vistas web y API."""

    @staticmethod
    def obtener_formularios_activos():
        return Formulario.objects.filter(activo=True)

    @staticmethod
    def obtener_pendientes(estudiante: Estudiante):
        """Formularios activos que el estudiante todavía no entregó."""
        entregados = EntregaFormulario.objects.filter(
            estudiante=estudiante
        ).values_list("formulario_id", flat=True)
        return Formulario.objects.filter(activo=True).exclude(id__in=entregados)

    @staticmethod
    def obtener_entregas(estudiante: Estudiante):
        return EntregaFormulario.objects.filter(estudiante=estudiante).select_related("formulario")

    @staticmethod
    @transaction.atomic
    def registrar_entrega(estudiante: Estudiante, formulario: Formulario, archivo_firmado):
        """
        Crea la entrega o reemplaza el archivo si todavía no fue
        recibida por el sistema (permite re-subir una versión corregida).
        """
        if not formulario.activo:
            raise ValueError("El formulario no está activo.")
        if archivo_firmado is None:
            raise ValueError("Debe adjuntar el archivo firmado.")

        entrega, creada = EntregaFormulario.objects.get_or_create(
            estudiante=estudiante,
            formulario=formulario,
            defaults={"archivo_firmado": archivo_firmado},
        )
        if not creada:
            if entrega.recibido_por_sistema:
                raise ValueError("La entrega ya fue recibida y no puede modificarse.")
            entrega.archivo_firmado = archivo_firmado
            entrega.save()
        return entrega

    @staticmethod
    def marcar_recibida(entrega: EntregaFormulario, recibida: bool = True):
        entrega.recibido_por_sistema = recibida
        entrega.save(update_fields=["recibido_por_sistema"])
        return entrega

    @staticmethod
    def estado_por_curso(curso: Curso, formulario: Formulario):
        """Para cada estudiante matriculado del curso, indica si entregó el formulario."""
        matriculas = Matricula.objects.filter(curso=curso, activa=True).select_related("estudiante")
        entregas = {
            e.estudiante_id: e
            for e in EntregaFormulario.objects.filter(
                formulario=formulario, estudiante__in=[m.estudiante for m in matriculas]
            )
        }
        resultado = []
        for m in matriculas:
            entrega = entregas.get(m.estudiante_id)
            resultado.append({
                "estudiante_id": m.estudiante_id,
                "estudiante": str(m.estudiante),
                "entregado": entrega is not None,
                "recibido": bool(entrega and entrega.recibido_por_sistema),
                "fecha_entrega": entrega.fecha_entrega if entrega else None,
            })
        return resultado

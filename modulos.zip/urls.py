# formularios/urls.py
from django.urls import path
from . import api_views

app_name = "formularios"

urlpatterns = [
    path("api/", api_views.formularios_disponibles_api, name="api_disponibles"),
    path("api/mis-entregas/", api_views.mis_entregas_api, name="api_mis_entregas"),
    path("api/<int:formulario_id>/entregar/", api_views.entregar_formulario_api, name="api_entregar"),
    path("api/entregas/<int:entrega_id>/recibida/", api_views.marcar_recibida_api, name="api_marcar_recibida"),
    path("api/curso/<int:curso_id>/formulario/<int:formulario_id>/", api_views.estado_por_curso_api, name="api_estado_curso"),
]

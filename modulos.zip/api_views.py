# formularios/api_views.py
from django.core.exceptions import ObjectDoesNotExist
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.decorators import api_view, parser_classes, permission_classes
from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from rest_framework.response import Response

from academico.models import Curso
from .models import EntregaFormulario, Formulario
from .services import ServicioFormulario


def _estudiante_o_none(user):
    try:
        return user.estudiante_perfil
    except ObjectDoesNotExist:
        return None


def _sin_estudiante():
    return Response({"detail": "El usuario no es un estudiante válido."},
                    status=status.HTTP_403_FORBIDDEN)


def _url(request, archivo):
    return request.build_absolute_uri(archivo.url) if archivo else None


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def formularios_disponibles_api(request):
    """Lista los formularios activos y, si es estudiante, marca si ya entregó cada uno."""
    estudiante = _estudiante_o_none(request.user)
    entregados = set()
    if estudiante:
        entregados = set(
            EntregaFormulario.objects.filter(estudiante=estudiante)
            .values_list("formulario_id", flat=True)
        )
    data = [
        {
            "id": f.id,
            "nombre": f.nombre,
            "descripcion": f.descripcion,
            "plantilla": _url(request, f.archivo),
            "entregado": f.id in entregados,
        }
        for f in ServicioFormulario.obtener_formularios_activos()
    ]
    return Response(data, status=status.HTTP_200_OK)


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def mis_entregas_api(request):
    estudiante = _estudiante_o_none(request.user)
    if not estudiante:
        return _sin_estudiante()
    data = [
        {
            "formulario": e.formulario.nombre,
            "fecha_entrega": e.fecha_entrega,
            "recibido_por_sistema": e.recibido_por_sistema,
            "archivo_firmado": _url(request, e.archivo_firmado),
        }
        for e in ServicioFormulario.obtener_entregas(estudiante)
    ]
    return Response(data, status=status.HTTP_200_OK)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
@parser_classes([MultiPartParser, FormParser])
def entregar_formulario_api(request, formulario_id):
    """El estudiante sube el formulario firmado (multipart: campo 'archivo_firmado')."""
    estudiante = _estudiante_o_none(request.user)
    if not estudiante:
        return _sin_estudiante()
    formulario = get_object_or_404(Formulario, pk=formulario_id)
    try:
        entrega = ServicioFormulario.registrar_entrega(
            estudiante, formulario, request.FILES.get("archivo_firmado")
        )
    except ValueError as e:
        return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)
    return Response(
        {"id": entrega.id, "formulario": formulario.nombre,
         "fecha_entrega": entrega.fecha_entrega,
         "recibido_por_sistema": entrega.recibido_por_sistema},
        status=status.HTTP_201_CREATED,
    )


@api_view(["POST"])
@permission_classes([IsAdminUser])
def marcar_recibida_api(request, entrega_id):
    """Personal administrativo confirma la recepción (body opcional: {"recibida": false})."""
    entrega = get_object_or_404(EntregaFormulario, pk=entrega_id)
    recibida = request.data.get("recibida", True)
    ServicioFormulario.marcar_recibida(entrega, bool(recibida))
    return Response({"id": entrega.id, "recibido_por_sistema": entrega.recibido_por_sistema})


@api_view(["GET"])
@permission_classes([IsAdminUser])
def estado_por_curso_api(request, curso_id, formulario_id):
    curso = get_object_or_404(Curso, pk=curso_id)
    formulario = get_object_or_404(Formulario, pk=formulario_id)
    return Response(ServicioFormulario.estado_por_curso(curso, formulario))

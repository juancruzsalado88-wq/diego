# formularios/models.py
from django.db import models
from core.models import Estudiante


class Formulario(models.Model):
    nombre = models.CharField(max_length=100, verbose_name="Nombre")
    descripcion = models.TextField(blank=True, verbose_name="Descripción")
    archivo = models.FileField(upload_to="formularios/", verbose_name="Archivo Plantilla")
    activo = models.BooleanField(default=True, verbose_name="Activo")

    class Meta:
        verbose_name = "Formulario"
        verbose_name_plural = "Formularios"

    def __str__(self):
        return self.nombre


class EntregaFormulario(models.Model):
    estudiante = models.ForeignKey(
        Estudiante,
        on_delete=models.CASCADE,
        related_name="entregas_formularios",
        verbose_name="Estudiante",
    )
    formulario = models.ForeignKey(
        Formulario,
        on_delete=models.CASCADE,
        related_name="entregas",
        verbose_name="Formulario",
    )
    fecha_entrega = models.DateTimeField(auto_now_add=True, verbose_name="Fecha de Entrega")
    archivo_firmado = models.FileField(upload_to="formularios_firmados/", verbose_name="Archivo Firmado")
    recibido_por_sistema = models.BooleanField(default=False, verbose_name="Recibido por Sistema")

    class Meta:
        verbose_name = "Entrega de Formulario"
        verbose_name_plural = "Entregas de Formularios"
        constraints = [
            models.UniqueConstraint(
                fields=["estudiante", "formulario"],
                name="unique_entrega_estudiante_formulario",
            )
        ]

    def __str__(self):
        return f"{self.estudiante} - {self.formulario}"

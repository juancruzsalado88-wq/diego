# formularios/admin.py
from django.contrib import admin
from .models import Formulario, EntregaFormulario


@admin.register(Formulario)
class FormularioAdmin(admin.ModelAdmin):
    list_display = ("nombre", "activo")
    list_filter = ("activo",)
    search_fields = ("nombre",)


@admin.action(description="Marcar entregas seleccionadas como recibidas")
def marcar_como_recibidas(modeladmin, request, queryset):
    queryset.update(recibido_por_sistema=True)


@admin.register(EntregaFormulario)
class EntregaFormularioAdmin(admin.ModelAdmin):
    list_display = ("estudiante", "formulario", "fecha_entrega", "recibido_por_sistema")
    list_filter = ("formulario", "recibido_por_sistema")
    search_fields = ("estudiante__apellido", "estudiante__nombre", "estudiante__dni")
    actions = [marcar_como_recibidas]

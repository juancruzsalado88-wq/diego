# salidas_educativas/services.py
from django.db import transaction

from academico.models import Matricula
from core.models import Estudiante, EstudianteTutor, Tutor
from .models import SalidaEducativa, ParticipacionSalida


class ServicioSalida:
    """Lógica de negocio de salidas educativas, reutilizable por vistas web y API."""

    @staticmethod
    def obtener_estudiantes_habilitados(salida: SalidaEducativa):
        """Estudiantes con matrícula activa en alguno de los cursos de la salida."""
        matriculas = (
            Matricula.objects.filter(curso__in=salida.cursos.all(), activa=True)
            .select_related("estudiante")
        )
        return list({m.estudiante_id: m.estudiante for m in matriculas}.values())

    @staticmethod
    @transaction.atomic
    def generar_participaciones(salida: SalidaEducativa) -> int:
        """Crea (sin autorizar) la participación de cada estudiante habilitado. Devuelve cuántas creó."""
        creadas = 0
        for estudiante in ServicioSalida.obtener_estudiantes_habilitados(salida):
            _, nueva = ParticipacionSalida.objects.get_or_create(
                salida=salida, estudiante=estudiante, defaults={"autorizado": False}
            )
            creadas += int(nueva)
        return creadas

    @staticmethod
    def _validar_habilitado(salida: SalidaEducativa, estudiante: Estudiante):
        if estudiante.id not in {e.id for e in ServicioSalida.obtener_estudiantes_habilitados(salida)}:
            raise ValueError("El estudiante no pertenece a los cursos de esta salida.")

    @staticmethod
    def establecer_autorizacion(salida, estudiante, autorizado: bool, observaciones: str = ""):
        """Uso administrativo/docente: no valida vínculo con tutor."""
        ServicioSalida._validar_habilitado(salida, estudiante)
        participacion, _ = ParticipacionSalida.objects.get_or_create(salida=salida, estudiante=estudiante)
        participacion.autorizado = autorizado
        if observaciones:
            participacion.observaciones = observaciones
        participacion.save()
        return participacion

    @staticmethod
    def autorizar_por_tutor(tutor: Tutor, salida, estudiante, autorizado: bool, observaciones: str = ""):
        """
        Un tutor sólo puede autorizar si está vinculado al estudiante
        y la relación no tiene restricción legal.
        """
        try:
            relacion = EstudianteTutor.objects.get(tutor=tutor, estudiante=estudiante)
        except EstudianteTutor.DoesNotExist:
            raise ValueError("El tutor no está asociado a este estudiante.")
        if relacion.restriccion_legal:
            raise ValueError("El tutor tiene una restricción legal sobre este estudiante.")
        return ServicioSalida.establecer_autorizacion(salida, estudiante, autorizado, observaciones)

    @staticmethod
    def obtener_salidas_de_estudiante(estudiante: Estudiante):
        return (
            SalidaEducativa.objects.filter(participaciones__estudiante=estudiante)
            .select_related("docente_responsable").distinct().order_by("fecha")
        )

    @staticmethod
    def resumen(salida: SalidaEducativa) -> dict:
        participaciones = salida.participaciones.select_related("estudiante")
        autorizados = [p for p in participaciones if p.autorizado]
        return {
            "total": participaciones.count(),
            "autorizados": len(autorizados),
            "pendientes": participaciones.count() - len(autorizados),
        }

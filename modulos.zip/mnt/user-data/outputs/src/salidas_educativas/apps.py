from django.apps import AppConfig


class SalidasEducativasConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "salidas_educativas"
    verbose_name = "Salidas Educativas"

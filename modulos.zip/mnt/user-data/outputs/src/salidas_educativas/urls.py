# salidas_educativas/urls.py
from django.urls import path
from . import api_views

app_name = "salidas_educativas"

urlpatterns = [
    path("api/mis-salidas/", api_views.mis_salidas_api, name="api_mis_salidas"),
    path("api/<int:salida_id>/participantes/", api_views.participantes_salida_api, name="api_participantes"),
    path("api/<int:salida_id>/generar-participaciones/", api_views.generar_participaciones_api, name="api_generar"),
    path("api/<int:salida_id>/estudiante/<int:estudiante_id>/autorizar/", api_views.autorizar_salida_api, name="api_autorizar"),
]

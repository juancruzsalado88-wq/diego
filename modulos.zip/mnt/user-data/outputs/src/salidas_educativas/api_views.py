# salidas_educativas/api_views.py
from django.core.exceptions import ObjectDoesNotExist
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from core.models import Estudiante
from .models import SalidaEducativa
from .services import ServicioSalida


def _perfil(user, nombre):
    try:
        return getattr(user, nombre)
    except ObjectDoesNotExist:
        return None


def _es_responsable_o_staff(user, salida) -> bool:
    if user.is_staff:
        return True
    docente = _perfil(user, "docente_perfil")
    return bool(docente and docente.id == salida.docente_responsable_id)


def _prohibido(msg="No tiene permisos para esta operación."):
    return Response({"detail": msg}, status=status.HTTP_403_FORBIDDEN)


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def mis_salidas_api(request):
    """Salidas del estudiante autenticado, con su estado de autorización."""
    estudiante = _perfil(request.user, "estudiante_perfil")
    if not estudiante:
        return _prohibido("El usuario no es un estudiante válido.")
    autorizadas = dict(
        estudiante.participaciones_salidas.values_list("salida_id", "autorizado")
    )
    data = [
        {
            "id": s.id,
            "nombre": s.nombre,
            "destino": s.destino,
            "fecha": s.fecha,
            "hora_salida": s.hora_salida,
            "hora_regreso": s.hora_regreso,
            "docente_responsable": str(s.docente_responsable),
            "autorizado": autorizadas.get(s.id, False),
        }
        for s in ServicioSalida.obtener_salidas_de_estudiante(estudiante)
    ]
    return Response(data, status=status.HTTP_200_OK)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def autorizar_salida_api(request, salida_id, estudiante_id):
    """El tutor autoriza o revoca. Body: {"autorizado": true, "observaciones": "..."}"""
    tutor = _perfil(request.user, "tutor_perfil")
    if not tutor:
        return _prohibido("El usuario no es un tutor válido.")
    salida = get_object_or_404(SalidaEducativa, pk=salida_id)
    estudiante = get_object_or_404(Estudiante, pk=estudiante_id)
    try:
        p = ServicioSalida.autorizar_por_tutor(
            tutor, salida, estudiante,
            bool(request.data.get("autorizado", True)),
            request.data.get("observaciones", ""),
        )
    except ValueError as e:
        return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)
    return Response({"estudiante": str(estudiante), "salida": salida.nombre, "autorizado": p.autorizado})


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def participantes_salida_api(request, salida_id):
    """Listado de participantes y resumen (docente responsable o staff)."""
    salida = get_object_or_404(SalidaEducativa, pk=salida_id)
    if not _es_responsable_o_staff(request.user, salida):
        return _prohibido()
    participantes = [
        {
            "estudiante_id": p.estudiante_id,
            "estudiante": str(p.estudiante),
            "autorizado": p.autorizado,
            "observaciones": p.observaciones,
        }
        for p in salida.participaciones.select_related("estudiante")
    ]
    return Response({"resumen": ServicioSalida.resumen(salida), "participantes": participantes})


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def generar_participaciones_api(request, salida_id):
    salida = get_object_or_404(SalidaEducativa, pk=salida_id)
    if not _es_responsable_o_staff(request.user, salida):
        return _prohibido()
    creadas = ServicioSalida.generar_participaciones(salida)
    return Response({"creadas": creadas}, status=status.HTTP_201_CREATED)

# salidas_educativas/admin.py
from django.contrib import admin
from .models import SalidaEducativa, ParticipacionSalida
from .services import ServicioSalida


class ParticipacionSalidaInline(admin.TabularInline):
    model = ParticipacionSalida
    extra = 0
    autocomplete_fields = ("estudiante",)


@admin.action(description="Generar participaciones desde los cursos seleccionados")
def generar_participaciones(modeladmin, request, queryset):
    total = sum(ServicioSalida.generar_participaciones(s) for s in queryset)
    modeladmin.message_user(request, f"Se crearon {total} participaciones nuevas.")


@admin.register(SalidaEducativa)
class SalidaEducativaAdmin(admin.ModelAdmin):
    list_display = ("nombre", "destino", "fecha", "hora_salida", "hora_regreso", "docente_responsable")
    list_filter = ("fecha", "cursos")
    search_fields = ("nombre", "destino")
    filter_horizontal = ("cursos",)
    inlines = [ParticipacionSalidaInline]
    actions = [generar_participaciones]


@admin.register(ParticipacionSalida)
class ParticipacionSalidaAdmin(admin.ModelAdmin):
    list_display = ("estudiante", "salida", "autorizado")
    list_filter = ("salida", "autorizado")
    search_fields = ("estudiante__apellido", "estudiante__nombre", "estudiante__dni")

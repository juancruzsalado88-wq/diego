# salidas_educativas/models.py
from django.db import models
from core.models import Docente, Estudiante
from academico.models import Curso


class SalidaEducativa(models.Model):
    nombre = models.CharField(max_length=150, verbose_name="Nombre del Evento")
    destino = models.CharField(max_length=200, verbose_name="Destino")
    descripcion = models.TextField(blank=True, verbose_name="Descripción")
    fecha = models.DateField(verbose_name="Fecha")
    hora_salida = models.TimeField(verbose_name="Hora de Salida")
    hora_regreso = models.TimeField(verbose_name="Hora de Regreso")
    docente_responsable = models.ForeignKey(
        Docente,
        on_delete=models.PROTECT,
        related_name="salidas_responsable",
        verbose_name="Docente Responsable",
    )
    cursos = models.ManyToManyField(
        Curso, related_name="salidas_educativas", verbose_name="Cursos Participantes"
    )

    class Meta:
        verbose_name = "Salida Educativa"
        verbose_name_plural = "Salidas Educativas"

    def __str__(self):
        return f"{self.nombre} - {self.destino} ({self.fecha})"


class ParticipacionSalida(models.Model):
    salida = models.ForeignKey(
        SalidaEducativa,
        on_delete=models.CASCADE,
        related_name="participaciones",
        verbose_name="Salida Educativa",
    )
    estudiante = models.ForeignKey(
        Estudiante,
        on_delete=models.CASCADE,
        related_name="participaciones_salidas",
        verbose_name="Estudiante",
    )
    autorizado = models.BooleanField(default=False, verbose_name="Autorizado")
    observaciones = models.TextField(blank=True, verbose_name="Observaciones")

    class Meta:
        verbose_name = "Participación en Salida"
        verbose_name_plural = "Participaciones en Salidas"
        constraints = [
            models.UniqueConstraint(
                fields=["salida", "estudiante"],
                name="unique_participacion_salida_estudiante",
            )
        ]

    def __str__(self):
        return f"{self.estudiante} - {self.salida} (Autorizado: {self.autorizado})"

# ---- config/urls.py ----
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", admin.site.urls),
    path("formularios/", include("formularios.urls")),
    path("salidas/", include("salidas_educativas.urls")),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# ---- config/settings.py (agregar) ----
# from pathlib import Path
# BASE_DIR = Path(__file__).resolve().parent.parent
# MEDIA_URL = "/media/"
# MEDIA_ROOT = BASE_DIR / "media"
